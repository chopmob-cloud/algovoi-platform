# AlgoVoi Commercial Licence v1.0 (LicenseRef-AlgoVoi-Commercial-1.0)

**Proprietary. Not open source.**

Copyright © AlgoVoi. All rights reserved.

This software (`algovoi-doc-archive-s3`) is a commercial product. No rights to use, copy, modify, distribute,
sublicense, or create derivative works are granted except under a valid AlgoVoi licence: the
**Self-Serve Starter Licence** (a clickwrap agreement accepted at purchase through the AlgoVoi store)
for self-serve Starter purchases, or a **separate written commercial agreement** with AlgoVoi
(Enterprise / On-premise / OEM).

The software is **runtime-licence-enforced** — it will not operate without a valid licence key
(`ALGOVOI_LICENSE_KEY`). It is **not** published to public package registries and must not be redistributed.

For Enterprise / On-premise / OEM terms, contact:
**Christopher Hopley — chopmob@gmail.com**

*This file is a notice only. It is not the licence agreement and grants no rights; the binding terms are
the Self-Serve Starter Licence (for self-serve Starter purchases) or the signed commercial agreement
(Enterprise / OEM).*
