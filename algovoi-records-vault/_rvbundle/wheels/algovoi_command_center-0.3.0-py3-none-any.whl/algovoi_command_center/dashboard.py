"""Server-rendered dashboard for the Compliance Command Center.

Renders a :class:`~algovoi_command_center.posture.Posture` as a standalone HTML page. Every figure is
shown with its verification status — the posture is evidence-backed, not asserted.
"""
from __future__ import annotations

import html

from algovoi_command_center.posture import Posture

_CSS = """
:root{--bg:#fbfbfa;--surface:#fff;--text:#1d1d1b;--muted:#6b6b66;--faint:#9a9a93;--line:#e7e6e1;
--ok:#0f6e56;--ok-bg:#e1f5ee;--warn:#854f0b;--info:#185fa5;--info-bg:#e6f1fb}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--text);font:15px/1.6 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif}
.wrap{max-width:980px;margin:0 auto;padding:28px 24px 48px}
.top{display:flex;align-items:flex-start;justify-content:space-between;gap:16px;flex-wrap:wrap;margin-bottom:24px}
h1{font-size:20px;font-weight:600;margin:0}
.sub{font-size:13px;color:var(--muted);margin-top:3px}
.pill{display:inline-flex;align-items:center;gap:6px;font-size:12px;padding:5px 11px;border-radius:8px}
.pill.ok{background:var(--ok-bg);color:var(--ok)}
.pill.bad{background:#fceaea;color:#a32d2d}
.btn{font-size:13px;padding:7px 14px;border:0.5px solid var(--line);background:var(--surface);border-radius:8px;color:var(--text);text-decoration:none;cursor:pointer}
.btn:hover{background:#f3f2ee}
.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin-bottom:20px}
.card{background:#f3f2ee;border-radius:8px;padding:14px 16px}
.card .lbl{font-size:13px;color:var(--muted)}
.card .val{font-size:26px;font-weight:600;margin-top:2px}
.card .vf{font-size:12px;color:var(--ok);margin-top:5px}
.panel{background:var(--surface);border:0.5px solid var(--line);border-radius:12px;padding:16px 20px;margin-bottom:16px}
.panel h2{font-size:15px;font-weight:600;margin:0 0 12px}
table{width:100%;border-collapse:collapse;font-size:13px}
td{padding:6px 0}
.muted{color:var(--muted)}
.mono{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:12px;color:var(--faint)}
.rt{text-align:right}
.vbadge{color:var(--ok)}
.vbadge.bad{color:#a32d2d}
.delta{display:flex;align-items:center;gap:10px;font-size:13px;padding:6px 0}
.delta .ic{width:18px;text-align:center;color:var(--muted)}
.callout{display:flex;gap:10px;background:var(--info-bg);color:var(--info);border-radius:8px;padding:14px 16px;font-size:13px;line-height:1.6}
"""


def _icon(ok: bool) -> str:
    cls = "vbadge" if ok else "vbadge bad"
    word = "Verified" if ok else "FAILED"
    return f'<span class="{cls}">&#10003; {word}</span>'


def _live(up: bool) -> str:
    cls = "vbadge" if up else "vbadge bad"
    word = "Live" if up else "Down"
    return f'<span class="{cls}">&#9679; {word}</span>'


def render_dashboard(p: Posture, user: dict | None = None, *, can_export: bool = True,
                     services: list | None = None) -> str:
    e = html.escape
    cards = "".join(
        f'<div class="card"><div class="lbl">{e(m.label)}</div>'
        f'<div class="val">{m.value:,}</div>'
        f'<div class="vf">{"&#10003; chain verified" if m.verified else "&#9888; unverified"}</div></div>'
        for m in p.metrics) or '<div class="card"><div class="lbl">No evidence ingested</div></div>'

    rows = "".join(
        f'<tr><td class="muted">{e(c.name)}</td>'
        f'<td class="rt mono">{e((c.head or str(c.entries))[:14])}</td>'
        f'<td class="rt">{_icon(c.verified)}</td></tr>'
        for c in p.chains) or '<tr><td class="muted">—</td></tr>'

    deltas = "".join(
        f'<div class="delta"><span class="ic">&#9679;</span><span style="flex:1">{e(d.text)}</span>'
        f'<span class="muted" style="font-size:12px">signed</span></div>'
        for d in p.deltas) or '<div class="muted" style="font-size:13px">No recent changes.</div>'

    status = ('<span class="pill ok">&#9989; all evidence offline-verifiable</span>'
              if p.all_verified else
              '<span class="pill bad">&#9888; verification failed — review below</span>')

    svc_rows = "".join(
        f'<tr><td class="muted">{e(s.get("name", ""))}</td>'
        f'<td class="muted">{e(s.get("type", ""))}</td>'
        f'<td class="rt mono">{e(s.get("url", ""))}</td>'
        f'<td class="rt">{_live(bool(s.get("up")))}</td></tr>'
        for s in (services or [])) or \
        '<tr><td class="muted">No products registered yet.</td></tr>'

    return f"""<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Compliance command center</title><style>{_CSS}</style></head><body><div class="wrap">
<div class="top"><div><h1>Compliance command center</h1>
<div class="sub">Estate: {e(p.estate)} &middot; {p.packs} evidence pack(s) &middot; self-hosted, air-gapped</div></div>
<div style="display:flex;gap:8px;align-items:center">
{f'<span class="muted" style="font-size:12px">{e(user["username"])} &middot; {e(user.get("role",""))}</span>' if user else ''}
{status}
{'<a class="btn" href="/export">&#8681; Export auditor pack</a>' if can_export else ''}
{'<a class="btn" href="/audit">Audit</a><a class="btn" href="/logout">Sign out</a>' if user else ''}</div></div>
<div class="cards">{cards}</div>
<div class="panel"><h2>Evidence integrity — verified offline, public key only</h2>
<table><tbody>{rows}</tbody></table></div>
<div class="panel"><h2>Live service health — polled on load, not asserted</h2>
<table><tbody>{svc_rows}</tbody></table></div>
<div class="panel"><h2>Recent posture changes</h2>{deltas}</div>
<div class="callout"><span>&#128274;</span><div>Nothing on this screen is <em>asserted</em>. Every figure is
recomputed from a Falcon-1024 signed, hash-linked chain — your auditor re-verifies the exported pack
offline, with no AlgoVoi software or service.</div></div>
</div></body></html>"""


def render_login(error: str = "") -> str:
    msg = (f'<div style="background:#fceaea;color:#a32d2d;border-radius:8px;padding:10px 12px;'
           f'font-size:13px;margin-bottom:14px">{html.escape(error)}</div>') if error else ""
    return f"""<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Sign in</title>
<style>{_CSS}</style></head><body><div class="wrap" style="max-width:380px;margin-top:8vh">
<h1 style="margin-bottom:4px">Compliance command center</h1>
<div class="sub" style="margin-bottom:20px">Sign in to continue</div>
<div class="panel">{msg}<form method="post" action="/login">
<label class="muted" style="font-size:13px">Username</label>
<input name="username" autofocus style="width:100%;height:36px;margin:4px 0 12px;padding:0 10px;border:0.5px solid var(--line);border-radius:8px">
<label class="muted" style="font-size:13px">Password</label>
<input name="password" type="password" style="width:100%;height:36px;margin:4px 0 16px;padding:0 10px;border:0.5px solid var(--line);border-radius:8px">
<button class="btn" type="submit" style="width:100%">Sign in</button></form></div></div></body></html>"""


def render_audit(entries: list[dict], verified: bool, reason: str, user: dict | None = None) -> str:
    e = html.escape
    rows = "".join(
        f'<tr><td class="muted">{e(str(x.get("recorded_at","")))}</td>'
        f'<td>{e(str(x.get("principal","")))} <span class="muted">{e(str(x.get("role","")))}</span></td>'
        f'<td>{e(str(x.get("action","")))}</td>'
        f'<td class="muted">{e(str(x.get("detail","")))}</td></tr>'
        for x in reversed(entries)) or '<tr><td class="muted">No console activity yet.</td></tr>'
    badge = ('<span class="pill ok">&#10003; audit chain verified</span>' if verified
             else f'<span class="pill bad">&#9888; {e(reason)}</span>')
    return f"""<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Console audit</title>
<style>{_CSS}</style></head><body><div class="wrap">
<div class="top"><div><h1>Console audit log</h1>
<div class="sub">Every console action, Falcon-signed and hash-linked &middot; offline-verifiable</div></div>
<div style="display:flex;gap:8px;align-items:center">{badge}
<a class="btn" href="/">&#8592; Dashboard</a></div></div>
<div class="panel"><table><tbody>{rows}</tbody></table></div></div></body></html>"""
