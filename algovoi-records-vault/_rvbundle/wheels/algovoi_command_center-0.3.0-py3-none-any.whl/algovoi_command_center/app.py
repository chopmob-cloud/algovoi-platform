"""Compliance Command Center — self-hosted web app (v1, with auth + RBAC + signed console audit).

Reads exported evidence packs from a watched ingest directory, re-verifies every chain offline, and
serves the compliance-posture dashboard, a posture API, and a consolidated auditor-pack export — behind
local-accounts auth + role-based access control. Every console action is appended to a Falcon-signed,
offline-verifiable audit chain.

Phase e adds LDAP/AD + OIDC/SAML SSO; phase f moves the console signing key into an HSM/KMS/Vault.
"""
from __future__ import annotations

import asyncio
import base64
import json
import os
import secrets
import time
import urllib.request
from typing import Annotated

from fastapi import FastAPI, Form, Header, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse, Response
from pydantic import BaseModel

from algovoi_command_center import __version__, licensing, roles
from algovoi_command_center.audit import ConsoleAuditLog, LocalSigner
from algovoi_command_center.auth import authenticate, make_session, read_session
from algovoi_command_center.dashboard import render_audit, render_dashboard, render_login
from algovoi_command_center.engine import ingest
from algovoi_command_center.export import build_auditor_pack
from algovoi_command_center.posture import build_posture
from algovoi_command_center.store import get_store
from algovoi_command_center.validation import build_ccc_validation_pack

_COOKIE = "cc_session"


def _ingest_dir() -> str:
    return os.environ.get("COMMAND_CENTER_INGEST_DIR", "./evidence-ingest")


def _estate() -> str:
    return os.environ.get("COMMAND_CENTER_ESTATE", "estate")


def _load():
    d = _ingest_dir()
    packs = ingest(d, get_store()) if os.path.isdir(d) else []
    return d, packs, build_posture(packs, estate=_estate())


def _env_or_file(name: str) -> str:
    v = os.environ.get(name)
    if v:
        return v
    f = os.environ.get(name + "_FILE")
    if f and os.path.exists(f):
        return open(f, encoding="utf-8").read().strip()
    raise RuntimeError(f"BYO-key custody needs {name} (or {name}_FILE)")


class ServiceIn(BaseModel):
    """A product self-registering with the console's live service bridge."""
    name: str
    type: str = "product"
    base_url: str
    health_path: str = "/health"


def _service_token() -> str:
    """The bearer token a product uses to self-register (POST /v1/services). A
    dedicated, narrowly-scoped token — not a full RBAC login. Set it explicitly via
    ``COMMAND_CENTER_SERVICE_TOKEN``, or let it bootstrap once into the data dir
    (0600) so a bare deployment comes up able to accept registrations."""
    v = os.environ.get("COMMAND_CENTER_SERVICE_TOKEN", "").strip()
    if v:
        return v
    base = os.environ.get("COMMAND_CENTER_DATA_DIR", ".")
    path = os.path.join(base, "command-center-service-token")
    if os.path.exists(path):
        return open(path, encoding="utf-8").read().strip()
    os.makedirs(base, exist_ok=True)
    tok = secrets.token_urlsafe(32)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(tok)
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass
    return tok


def _probe(name: str, svc: dict, timeout: float = 3.0) -> dict:
    """Synchronously poll one service's health (stdlib urllib — no extra runtime dep).
    Run off the event loop via asyncio.to_thread; never raises."""
    url = svc["base_url"].rstrip("/") + svc["health_path"]
    entry = {"name": name, "type": svc.get("type", ""), "url": url,
             "registered_at": svc.get("registered_at")}
    try:
        with urllib.request.urlopen(url, timeout=timeout) as r:  # noqa: S310
            entry["up"] = 200 <= r.status < 300
            raw = r.read(2048).decode("utf-8", "replace")
        try:
            entry["detail"] = json.loads(raw)
        except Exception:
            entry["detail"] = raw[:120]
    except Exception as exc:  # noqa: BLE001
        entry["up"] = False
        entry["detail"] = f"unreachable: {type(exc).__name__}"
    return entry


async def _poll_services() -> list[dict]:
    """Poll every registered service's health concurrently, on demand (no background
    loop). Mirrors the substrate-2 control plane's /v1/posture."""
    svcs = get_store().services_load()
    if not svcs:
        return []
    return list(await asyncio.gather(*(asyncio.to_thread(_probe, n, s) for n, s in svcs.items())))


def _console_signer():
    """Build the console's signer. ``COMMAND_CENTER_KEY_CUSTODY`` selects custody:

    - ``local`` (default): Falcon key in a local key file (bootstrapped on first run);
    - ``kms`` / ``vault`` / ``pkcs11``: BYO-key — the console public key + a *wrapped* secret key
      held in your AWS KMS / HashiCorp Vault / PKCS#11 HSM, unwrapped only at sign time (the existing
      ``algovoi-doc-archive-{kms,vault,pkcs11}`` adapters). The clear key never sits at rest.
    """
    custody = os.environ.get("COMMAND_CENTER_KEY_CUSTODY", "local")
    if custody == "local":
        path = os.environ.get("COMMAND_CENTER_KEY_FILE", "./command-center-key.json")
        if os.path.exists(path):
            d = json.load(open(path, encoding="utf-8"))
            return LocalSigner(base64.b64decode(d["pk"]), base64.b64decode(d["sk"]))
        from pqcrypto.sign.falcon_1024 import generate_keypair
        pk, sk = generate_keypair()
        json.dump({"pk": base64.b64encode(pk).decode(), "sk": base64.b64encode(sk).decode()},
                  open(path, "w", encoding="utf-8"))
        return LocalSigner(pk, sk)

    pk = base64.b64decode(_env_or_file("COMMAND_CENTER_CONSOLE_PUBKEY"))
    wrapped = base64.b64decode(_env_or_file("COMMAND_CENTER_CONSOLE_WRAPPED_KEY"))
    if custody == "kms":
        from algovoi_doc_archive_kms import kms_signer
        return kms_signer(pk, wrapped, key_id=os.environ["COMMAND_CENTER_KMS_KEY_ID"])
    if custody == "vault":
        from algovoi_doc_archive_vault import vault_signer
        return vault_signer(pk, wrapped, key_name=os.environ["COMMAND_CENTER_VAULT_KEY"],
                            url=os.environ.get("VAULT_ADDR"), token=os.environ.get("VAULT_TOKEN"))
    if custody == "pkcs11":
        raise RuntimeError("pkcs11 custody needs an integrator-supplied python-pkcs11 session; "
                           "construct the signer with algovoi_doc_archive_pkcs11.pkcs11_signer and "
                           "pass it to create_app() directly.")
    raise RuntimeError(f"unknown COMMAND_CENTER_KEY_CUSTODY: {custody!r}")


def create_app(signer=None) -> FastAPI:
    licensing.require_license()  # fail-closed — no valid Command Center licence, no app
    app = FastAPI(title="AlgoVoi Compliance Command Center", version=__version__)
    console_signer = signer or _console_signer()
    _audit_file = os.environ.get("COMMAND_CENTER_AUDIT_FILE")
    audit = ConsoleAuditLog(_audit_file if _audit_file else get_store(), console_signer)

    service_token = _service_token()

    def user_of(request: Request) -> dict | None:
        return read_session(request.cookies.get(_COOKIE))

    def _is_service(authorization: str | None) -> bool:
        token = (authorization[7:].strip()
                 if authorization and authorization.startswith("Bearer ") else None)
        return bool(token) and secrets.compare_digest(token, service_token)

    @app.get("/health")
    async def health() -> JSONResponse:
        return JSONResponse({"status": "ok", "version": __version__})

    @app.get("/login", response_class=HTMLResponse)
    async def login_page(request: Request):
        if user_of(request):
            return RedirectResponse("/", status_code=303)
        return HTMLResponse(render_login())

    @app.post("/login")
    async def login(request: Request, username: str = Form(...), password: str = Form(...)):
        u = authenticate(username, password)
        if not u:
            audit.append(action="login_failed", principal=username, detail="bad credentials")
            return HTMLResponse(render_login("Invalid username or password."), status_code=401)
        audit.append(action="login", principal=u["username"], role=u["role"])
        resp = RedirectResponse("/", status_code=303)
        resp.set_cookie(_COOKIE, make_session(u["username"], u["role"]), httponly=True, samesite="lax")
        return resp

    @app.get("/logout")
    async def logout(request: Request):
        u = user_of(request)
        if u:
            audit.append(action="logout", principal=u["username"], role=u["role"])
        resp = RedirectResponse("/login", status_code=303)
        resp.delete_cookie(_COOKIE)
        return resp

    @app.get("/", response_class=HTMLResponse)
    async def dashboard(request: Request):
        u = user_of(request)
        if not u:
            return RedirectResponse("/login", status_code=303)
        if not roles.can(u["role"], "view_dashboard"):
            return HTMLResponse("Forbidden", status_code=403)
        audit.append(action="view_dashboard", principal=u["username"], role=u["role"])
        _d, _packs, posture = _load()
        services = await _poll_services()
        return HTMLResponse(render_dashboard(posture, u, can_export=roles.can(u["role"], "export_pack"),
                                             services=services))

    # ── Live service bridge: products self-register, the console polls their health ──
    @app.post("/v1/services")
    async def register_service(body: ServiceIn,
                               authorization: Annotated[str | None, Header()] = None):
        if not _is_service(authorization):
            return JSONResponse({"error": "service token required"}, status_code=401)
        registered_at = int(time.time())
        get_store().service_register(body.name, body.type, body.base_url.rstrip("/"),
                                     body.health_path, registered_at)
        audit.append(action="service_register", principal=body.name, role="service",
                     detail=body.base_url.rstrip("/"))
        return JSONResponse({"name": body.name, "registered": True})

    @app.get("/v1/services")
    async def list_services():
        return JSONResponse({"services": [{"name": n, **v}
                                          for n, v in get_store().services_load().items()]})

    @app.delete("/v1/services/{name}")
    async def remove_service(name: str,
                             authorization: Annotated[str | None, Header()] = None):
        if not _is_service(authorization):
            return JSONResponse({"error": "service token required"}, status_code=401)
        if name not in get_store().services_load():
            return JSONResponse({"error": "unknown service"}, status_code=404)
        get_store().service_remove(name)
        audit.append(action="service_remove", principal=name, role="service", detail="removed")
        return JSONResponse({"name": name, "removed": True})

    @app.get("/api/services")
    async def api_services(request: Request):
        u = user_of(request)
        if not u or not roles.can(u["role"], "view_dashboard"):
            return JSONResponse({"error": "unauthorized"}, status_code=401)
        services = await _poll_services()
        return JSONResponse({"services": services,
                             "all_up": bool(services) and all(s["up"] for s in services)})

    @app.get("/api/posture")
    async def api_posture(request: Request):
        u = user_of(request)
        if not u or not roles.can(u["role"], "view_evidence"):
            return JSONResponse({"error": "unauthorized"}, status_code=401)
        _d, _packs, posture = _load()
        return JSONResponse({
            "estate": posture.estate, "packs": posture.packs, "all_verified": posture.all_verified,
            "metrics": [{"key": m.key, "label": m.label, "value": m.value, "verified": m.verified}
                        for m in posture.metrics],
            "chains": [{"name": c.name, "type": c.entry_type, "entries": c.entries,
                        "verified": c.verified, "head": c.head} for c in posture.chains]})

    @app.get("/export")
    async def export(request: Request):
        u = user_of(request)
        if not u:
            return RedirectResponse("/login", status_code=303)
        if not roles.can(u["role"], "export_pack"):
            return Response("Forbidden — your role cannot export evidence.", status_code=403)
        d, packs, posture = _load()
        audit.append(action="export_auditor_pack", principal=u["username"], role=u["role"],
                     detail=f"{posture.packs} pack(s)")
        blob = build_auditor_pack(d, packs, posture)
        return Response(content=blob, media_type="application/zip", headers={
            "Content-Disposition": 'attachment; filename="auditor-evidence-pack.zip"'})

    @app.get("/validation/pack")
    async def validation_pack(request: Request):
        u = user_of(request)
        if not u:
            return RedirectResponse("/login", status_code=303)
        if not roles.can(u["role"], "export_pack"):
            return Response("Forbidden: your role cannot export the validation pack.", status_code=403)
        _d, _packs, posture = _load()
        audit.append(action="export_validation_pack", principal=u["username"], role=u["role"])
        blob = build_ccc_validation_pack(console_signer, audit, posture)
        return Response(content=blob, media_type="application/zip", headers={
            "Content-Disposition": 'attachment; filename="system-validation-pack.zip"'})

    @app.get("/audit", response_class=HTMLResponse)
    async def audit_page(request: Request):
        u = user_of(request)
        if not u:
            return RedirectResponse("/login", status_code=303)
        if not roles.can(u["role"], "view_audit"):
            return HTMLResponse("Forbidden", status_code=403)
        ok, reason = audit.verify()
        return HTMLResponse(render_audit(audit.entries(), ok, reason, u))

    return app


app = create_app()


def main() -> None:
    """Console entry point — serve the command center (``algovoi-command-center``)."""
    import uvicorn
    uvicorn.run("algovoi_command_center.app:app",
                host=os.environ.get("COMMAND_CENTER_HOST", "0.0.0.0"),
                port=int(os.environ.get("COMMAND_CENTER_PORT", "8200")))
