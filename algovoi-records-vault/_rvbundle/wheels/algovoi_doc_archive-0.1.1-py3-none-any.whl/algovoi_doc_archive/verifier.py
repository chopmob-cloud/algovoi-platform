"""Offline verification of archive entries and the tamper-evident chain (pure, never raises)."""
from __future__ import annotations

from algovoi_doc_archive import signing
from algovoi_doc_archive.models import VerifyChainResult, VerifyEntryResult


def verify_entry(receipt: str, public_key: bytes) -> VerifyEntryResult:
    """Verify a single archive entry: envelope + type + Falcon signature."""
    try:
        payload, sig, kid = signing.open_envelope(receipt)
    except Exception:  # noqa: BLE001
        return VerifyEntryResult(verified=False, status="invalid",
                                 error_code="INVALID_RECEIPT", error_message="malformed receipt envelope")
    if payload.get("type") != "archive_entry":
        return VerifyEntryResult(verified=False, status="invalid", kid=kid,
                                 error_code="WRONG_TYPE", error_message="not an archive_entry envelope")
    if not signing.verify_payload(payload, sig, public_key):
        return VerifyEntryResult(verified=False, status="invalid", kid=kid,
                                 error_code="TAMPERED_SIGNATURE", error_message="signature verification failed")
    return VerifyEntryResult(
        verified=True, status="valid", entry_id=payload.get("entry_id"), seq=payload.get("seq"),
        doc_hash=payload.get("doc_hash"), title=payload.get("title"), content_type=payload.get("content_type"),
        enc_alg=payload.get("enc_alg"), prev_receipt_hash=payload.get("prev_receipt_hash"),
        kid=kid, archived_at=payload.get("archived_at"))


def verify_chain(receipts: list[str], public_key: bytes) -> VerifyChainResult:
    """Verify the whole append-only chain: each entry signed, sequential, and correctly hash-linked.

    A pass proves no entry was altered, inserted, removed, reordered, or back-dated.
    """
    prev: str | None = None
    for i, r in enumerate(receipts):
        try:
            payload, sig, _ = signing.open_envelope(r)
        except Exception:  # noqa: BLE001
            return VerifyChainResult(valid=False, length=i, broken_at=i, reason="malformed_entry")
        if payload.get("type") != "archive_entry":
            return VerifyChainResult(valid=False, length=i, broken_at=i, reason="wrong_type")
        if not signing.verify_payload(payload, sig, public_key):
            return VerifyChainResult(valid=False, length=i, broken_at=i, reason="bad_signature")
        if payload.get("seq") != i:
            return VerifyChainResult(valid=False, length=i, broken_at=i, reason="seq_mismatch")
        if payload.get("prev_receipt_hash") != prev:
            return VerifyChainResult(valid=False, length=i, broken_at=i, reason="chain_break")
        prev = signing.payload_hash(payload)
    return VerifyChainResult(valid=True, length=len(receipts), head_receipt_hash=prev)
