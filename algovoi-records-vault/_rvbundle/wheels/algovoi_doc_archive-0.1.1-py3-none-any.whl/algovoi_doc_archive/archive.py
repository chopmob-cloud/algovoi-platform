"""The Verifiable Archive engine: content-address → encrypt → sign → append to a hash-linked chain."""
from __future__ import annotations

from algovoi_doc_archive import licensing

import hashlib
import json
from datetime import datetime, timezone
from uuid import uuid4

from algovoi_doc_archive import signing
from algovoi_doc_archive.backend import StorageBackend
from algovoi_doc_archive.encryption import Encryptor
from algovoi_doc_archive.models import VerifyChainResult
from algovoi_doc_archive.signer import LocalSigner, Signer
from algovoi_doc_archive.verifier import verify_chain as _verify_chain

_HEAD = "archive/head.json"


def _iso(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ")


def _sha(b: bytes) -> str:
    return "sha256:" + hashlib.sha256(b).hexdigest()


class Archive:
    """Append-only, tamper-evident, encrypted document archive over a pluggable storage backend.

    Each entry binds a document's content hash into a Falcon-1024-signed receipt that links to the
    previous entry (``prev_receipt_hash``), forming an offline-verifiable chain. Documents are
    encrypted by ``encryptor`` **before** they reach the backend, so storage only ever sees
    ciphertext. ``notarize`` is append-only and assumes a single writer per archive.
    """

    def __init__(
        self,
        *,
        public_key: bytes | None = None,
        storage: StorageBackend,
        secret_key: bytes | None = None,
        encryptor: Encryptor | None = None,
        signer: Signer | None = None,
        issuer_did: str = "did:web:issuer.example.com",
    ) -> None:
        licensing.require_license()   # fail-closed: no valid AlgoVoi OEM licence -> refuse
        # Key custody is pluggable via ``signer`` (HSM / KMS / Vault). For backward compatibility,
        # ``public_key`` (+ optional ``secret_key``) wraps an in-process LocalSigner. Omit both
        # secret_key and a signing-capable signer for a read-only / audit view (verify, list, retrieve).
        if signer is None:
            if public_key is None:
                raise ValueError("provide signer= or public_key=")
            signer = LocalSigner(public_key, secret_key)
        self.signer = signer
        self.sk = secret_key            # retained for backward compatibility (may be None)
        self.pk = signer.public_key()
        self.storage = storage
        self.enc = encryptor
        self.issuer_did = issuer_did
        self.kid = signer.kid()

    async def head(self) -> dict:
        raw = await self.storage.get(_HEAD)
        return json.loads(raw) if raw else {"seq_count": 0, "last_receipt_hash": None, "last_entry_id": None}

    async def notarize(
        self,
        *,
        data: bytes | None = None,
        doc_hash: str | None = None,
        title: str = "",
        content_type: str = "application/octet-stream",
        metadata: dict | None = None,
    ) -> dict:
        """Archive a document. Pass ``data`` to store (encrypted), or ``doc_hash`` alone to notarize
        existence without storing the document."""
        if not self.signer.can_sign():
            raise RuntimeError("Archive is read-only (no signing-capable key/signer); cannot notarize")
        if data is None and not doc_hash:
            raise ValueError("provide data or doc_hash")

        stored, enc_alg, doc_size = False, "none", None
        if data is not None:
            h = _sha(data)
            if doc_hash and doc_hash != h:
                raise ValueError("doc_hash does not match data")
            doc_hash, doc_size = h, len(data)
            blob = self.enc.encrypt(data) if self.enc is not None else data
            enc_alg = self.enc.alg if self.enc is not None else "none"
            await self.storage.put(f"blob/{h.split(':', 1)[1]}", blob)
            stored = True

        head = await self.head()
        seq, prev = head["seq_count"], head["last_receipt_hash"]
        now = datetime.now(timezone.utc).replace(microsecond=0)
        eid = str(uuid4())
        payload = {
            "type": "archive_entry", "version": "1", "entry_id": eid, "seq": seq,
            "doc_hash": doc_hash, "doc_size": doc_size, "content_type": content_type,
            "title": title, "metadata": metadata or {}, "enc_alg": enc_alg, "stored": stored,
            "prev_receipt_hash": prev, "issuer_did": self.issuer_did, "kid": self.kid,
            "archived_at": _iso(now),
        }
        receipt = signing.make_envelope_with(payload, self.signer)
        await self.storage.put(f"entry/{seq:012d}.json", receipt.encode())
        await self.storage.put(_HEAD, json.dumps(
            {"seq_count": seq + 1, "last_receipt_hash": signing.payload_hash(payload), "last_entry_id": eid}).encode())
        return {"entry_id": eid, "seq": seq, "doc_hash": doc_hash, "stored": stored, "enc_alg": enc_alg,
                "prev_receipt_hash": prev, "receipt": receipt, "kid": self.kid, "archived_at": _iso(now)}

    async def get_entry(self, seq: int) -> str | None:
        raw = await self.storage.get(f"entry/{int(seq):012d}.json")
        return raw.decode() if raw else None

    async def list_entries(self) -> list[str]:
        head = await self.head()
        out: list[str] = []
        for i in range(head["seq_count"]):
            e = await self.get_entry(i)
            if e is None:
                break
            out.append(e)
        return out

    async def retrieve(self, *, doc_hash: str) -> bytes:
        """Fetch and decrypt a stored document, verifying its hash matches. Raises if absent/altered."""
        hexh = doc_hash.split(":", 1)[1] if ":" in doc_hash else doc_hash
        blob = await self.storage.get(f"blob/{hexh}")
        if blob is None:
            raise FileNotFoundError("document not stored in archive (hash-only entry or unknown hash)")
        if self.enc is not None:
            if not self.enc.can_decrypt:
                raise PermissionError("decryption key not available on this node")
            data = self.enc.decrypt(blob)
        else:
            data = blob
        if hashlib.sha256(data).hexdigest() != hexh:
            raise ValueError("integrity check failed: document does not match its recorded hash")
        return data

    async def verify_chain(self) -> VerifyChainResult:
        return _verify_chain(await self.list_entries(), self.pk)
